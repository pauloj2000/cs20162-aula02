# exemplo
Projeto de referência (exemplo) básico em Java.

## Lembretes...
- `mvn javadoc:javadoc` (geração de documentação)
- `mvn package -P cobertura` (executação de testes e relatório de cobertura)
- `mvn exec:java -Dexec.mainClass="com.github.kyriosdata.exemplo.ProgramaCalendario` (execução do programa)
